$(function(){
	'use strict';

 	// countdown
	$(".countdown").countdown();

});




